#include <hidef.h>      /* common defines and macros */
#include "derivative.h"      /* derivative-specific definitions */


// File created with small memory model and minimal setup


// Function declarations
void serialInit(void);
interrupt 21 void serialISR();


// Defining constants
#define carriageReturn 13;


// Global variables 
char buffer[8];
int stringLength;



// Main
void main(void) {
  /* put your own code here */
  
    
    serialInit(); //Initialising the serial port

	EnableInterrupts;

    //From minimal setup
    for(;;) {
        _FEED_COP(); /* feeds the dog */
    } /* loop forever */
  /* please make sure that you never leave main */
}



// Defining the serial initialisation function
void serialInit(void){
    
    
    //Setting baud rate to 9600
    SCI1BDL = 0x9C;
    SCI1BDH = 0;
    
    //Setting the control register 1 to 0
    SCI1CR1 = 0;
    
    /*
    Setting the control register bit 1,2,4 to be 1 (0010110)
    to enable recieve interrupt, transmit and receive data
    */
    SCI1CR2 = 0b0010110;
}


//Defining the interrupt handling function for the serial ISR
interrupt 21 void serialISR(){
   
   int i;
   int j;
   
   //Outputting a string to show detection
   char detect[] = "detected\r\n";
   
   //Check if data is received via RDRF flag
   if (SCI1SR1 & 0x20){
   
        //Checking for carriage return
        if(SCI1DRL = carriageReturn){
            
            
            //Looping to send out all characters
            for(i = 0; i!= stringLength ; i++){
                    
                 //Checking if data is ready to be sent   
                 while(!(SCI1SR1 & 0x80)){
                    
                    // Write to serial
                    SCI1DRL = buffer[i];
                    
                    for(j=0; j!=8;j++){
                        while(!(SCI1SR1 & 0x80));
                            SCI1DRL = detect[j];
                    }
                    
                 }
            
            }
            
            //Resetting the string length
            stringLength=0;
            
        }
        //Storing each character of sentence in buffer
        else{
            buffer[stringLength]= SCI1DRL;
            stringLength++;
        }
   }
}
            
            
    
}