#ifndef SERIAL_HEADER
#define SERIAL_HEADER

//Initialise the serial port
void serialInit(void);

//Serial interrupt definition
interrupt 21 void serialISR();



#endif
